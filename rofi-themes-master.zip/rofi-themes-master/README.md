## Because of lack of time to maintain this repository, its now archived.

## Official rofi-themes repository


When submitting a theme, please include a small copyright header, this way the theme can be included in the official set and shipped with rofi.
