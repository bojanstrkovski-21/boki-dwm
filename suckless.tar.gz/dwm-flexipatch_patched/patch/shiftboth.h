static void shiftboth(const Arg *arg);
