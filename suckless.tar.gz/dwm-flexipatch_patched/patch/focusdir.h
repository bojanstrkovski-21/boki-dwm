static void focusdir(const Arg *arg);

