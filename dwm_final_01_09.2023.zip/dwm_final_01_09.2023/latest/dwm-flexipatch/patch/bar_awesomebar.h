static int width_awesomebar(Bar *bar, BarArg *a);
static int draw_awesomebar(Bar *bar, BarArg *a);
static int click_awesomebar(Bar *bar, Arg *arg, BarArg *a);

