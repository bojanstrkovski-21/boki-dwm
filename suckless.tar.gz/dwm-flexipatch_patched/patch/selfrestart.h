char *get_dwm_path();
void self_restart(const Arg *arg);

