static void createpreview(Monitor *m);
static void hidetagpreview(Monitor *m);
static void showtagpreview(int tag, int x, int y);
static void tagpreviewswitchtag(void);
