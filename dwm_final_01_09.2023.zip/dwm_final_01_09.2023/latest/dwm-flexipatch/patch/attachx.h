static void attachx(Client *c);

