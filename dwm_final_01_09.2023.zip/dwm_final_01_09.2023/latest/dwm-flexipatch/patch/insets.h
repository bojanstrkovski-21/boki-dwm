static void setinset(Monitor *m, Inset inset);
static void updateinset(const Arg *arg);

